# 18b program file
[program file](program.png)

# 18b sample output
[sample output](sampleoutput.png)

# 18b tested output
[tested output](testedoutput.png)
