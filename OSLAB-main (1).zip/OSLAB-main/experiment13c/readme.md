# 13c program file
[program file](program.jpg)

# 13c sample output
[sample output](sampleoutput.png)

# 13c tested output
[tested output](testedoutput.png)
