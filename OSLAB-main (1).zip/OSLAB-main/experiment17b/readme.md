# 17b program file
[program file](program.jpg)

# 17b sample output
[sample output](sampleoutput.png)

# 17b tested output
[tested output](testedoutput.png)
