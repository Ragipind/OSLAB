# 10a program file
[program file](program.png.jpg)

# 10a sample output
[sample output](sampleoutput.png.jpg)

# 10a tested output
[tested output](testedoutput.png.jpg)
