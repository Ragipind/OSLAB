# 16b program file
[program file](program.png)

# 16b sample output
[sample output](sampleoutput.png)

# 16b tested output
[tested output](testedoutput.png)
