# 9c program file
[program file](program.png.jpg)

# 9c sample output
[sample output](sampleoutput.png.jpg)

# 9c tested output
[tested output](testedoutput.png.jpg)
