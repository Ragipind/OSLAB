# 18a program file
[program file](program.png)

# 18a sample output
[sample output](sampleoutput.png)

# 18a tested output
[tested output](testedoutput.png)
