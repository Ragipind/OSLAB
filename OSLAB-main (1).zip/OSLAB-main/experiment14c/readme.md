# 14c program file
[program file](program1.jpg)

# 14c sample output
[sample output](sampleoutput.jpg)

# 14c tested output
[tested output](testedoutput.jpg)
