# 16c program file
[program file](program.png)

# 16c sample output
[sample output](sampleoutput.png)

# 16c tested output
[tested output](testedoutput.png)
