# 9a program file
[program file](program.png)

# 9a sample output
[sample output](programoutput.png)

# 9a tested output
[tested output](testedoutput.png)
